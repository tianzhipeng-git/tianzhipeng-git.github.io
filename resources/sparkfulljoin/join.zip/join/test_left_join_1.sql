EXPLAIN
WITH t1 AS
(
	SELECT  device_id
	       ,imp_count AS t1_imp_count
	FROM `fin_dm_data_ai`.`dm_eco_device_feature_impclk_mid_pdi`
	WHERE prange = '1w'
	AND pday = '20230601' 
) , t2 AS
(
	SELECT  device_id
	       ,imp_count AS t2_imp_count
	FROM `fin_dm_data_ai`.`dm_eco_device_feature_impclk_mid_pdi`
	WHERE prange = '1w'
	AND pday = '20230602' 
) , t3 AS
(
	SELECT  device_id
	       ,imp_count AS t3_imp_count
	FROM `fin_dm_data_ai`.`dm_eco_device_feature_impclk_mid_pdi`
	WHERE prange = '1w'
	AND pday = '20230603' 
) , t4 AS
(
	SELECT  device_id
	       ,imp_count AS t4_imp_count
	FROM `fin_dm_data_ai`.`dm_eco_device_feature_impclk_mid_pdi`
	WHERE prange = '1w'
	AND pday = '20230604' 
)
SELECT  coalesce(t123.device_id ,t4.device_id) AS device_id
       ,t1_imp_count
       ,t2_imp_count
       ,t3_imp_count
       ,t4_imp_count
FROM
(
	SELECT  coalesce(t12.device_id ,t3.device_id) AS device_id
	       ,t1_imp_count
	       ,t2_imp_count
	       ,t3_imp_count
	FROM
	(
		SELECT  coalesce(t1.device_id ,t2.device_id) AS device_id
		       ,t1_imp_count
		       ,t2_imp_count
		FROM t1
		LEFT OUTER JOIN t2
		ON t1.device_id = t2.device_id
	) t12
	LEFT OUTER JOIN t3
	ON t12.device_id = t3.device_id
) t123
LEFT OUTER JOIN t4
ON t123.device_id = t4.device_id
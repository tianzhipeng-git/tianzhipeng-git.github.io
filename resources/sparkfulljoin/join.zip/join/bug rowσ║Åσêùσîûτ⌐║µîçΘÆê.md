

## 
可能原因
- Row的实现有问题, get字段的时候就空指针了
  - 排除, 逐行检查MultiRow和原始JoinedRow, 没问题.

- 整个JoinExec的字段处理有问题, 上级几个字段, 下级几个字段, 这个Exec输入/输出是几个字段, 子的iterator几个字段

- 疑问, 可能是show的原因吧, 从原始join看, 最终都project成9个StringType列了

- MultiJoinedRow中 join不上的时候, 缺失的路, 确实用的`val nullRows = inputs.map(x => new GenericInternalRow(x._1.output.length))`填充的
  - 这个GenericInternalRow有没有问题, 是否从他get东西会空指针? 不会,原始join也用这个, 会判断isNullAt
- 因为过程是先保存在MultiJoinedRow, 
  - 然后经过`resultProj: InternalRow => InternalRow = UnsafeProjection.create(output, output)`映射成unsafe了吧,
  - 后来又SafeProjection(A projection that could turn UnsafeRow into GenericInternalRow)转回去了
- 担心是某处的isNullAt判断错误, 或者某处转化没根据isNullAt来?
  - SafeProjection引用的BoundReference判断了isNullAt啊
    - 不对. 有多个create方法, 实际调用的Seq[Expression]参数的, 就看expressions参数了
    - 


```
private def collectFromPlan(plan: SparkPlan): Array[T] = {
    val fromRow = resolvedEnc.createDeserializer()
    plan.executeCollect().map(fromRow) //调用下面的↓
}


//org.apache.spark.sql.catalyst.encoders.ExpressionEncoder.Deserializer#apply

    override def apply(row: InternalRow): T = try {
      if (constructProjection == null) {
        constructProjection = SafeProjection.create(expressions)
      }
      constructProjection(row).get(0, anyObjectType).asInstanceOf[T]
    } catch {
      case e: Exception =>
        throw QueryExecutionErrors.expressionDecodingError(e, expressions)
    }

//三种SafeProjection, 调用的是Seq[Expression]
  def create(schema: StructType): Projection = create(schema.fields.map(_.dataType))
  def create(fields: Array[DataType]): Projection = {
    createObject(fields.zipWithIndex.map(x => new BoundReference(x._2, x._1, true)))
  }
  def create(exprs: Seq[Expression]): Projection = {
    createObject(exprs)
  }

```

经过原始join和自己join, debug断点到这挨个对比, 发现expressions变量不一样:
我的:
StructField(a,StringType,false)
StructField(b,StringType,true)
StructField(c,StringType,false)
...
原始:
全是StructField(b,StringType,true) 

这个变量从哪生成? 从logicalPlan的output

bug原因: output少加了.map(_.withNullability(true))
  override def output: Seq[Attribute] = {
    inputs.flatMap(i => i._1.output).这里
  }
select count(*) from csv.`/user/hive/warehouse/fin_dm_data_ai.db/dm_eco_hdfs_common/tzp/multijoin1`;
382324537

select count(*) from csv.`/user/hive/warehouse/fin_dm_data_ai.db/dm_eco_hdfs_common/tzp/multijoin2`;
324165172

SELECT  t1._c0
FROM
(
	SELECT  *
	FROM csv.`/user/hive/warehouse/fin_dm_data_ai.db/dm_eco_hdfs_common/tzp/multijoin1`
) t1
LEFT JOIN
(
	SELECT  *
	FROM csv.`/user/hive/warehouse/fin_dm_data_ai.db/dm_eco_hdfs_common/tzp/multijoin2`
) t2
ON t1._c0 = t2._c0
WHERE t2._c0 is null
LIMIT 10
-- 0条??

select count(distinct _c0) from csv.`/user/hive/warehouse/fin_dm_data_ai.db/dm_eco_hdfs_common/tzp/multijoin1`;
321810802
select count(distinct _c0) from csv.`/user/hive/warehouse/fin_dm_data_ai.db/dm_eco_hdfs_common/tzp/multijoin2`;
321810802


select count(*) from csv.`/user/hive/warehouse/fin_dm_data_ai.db/dm_eco_hdfs_common/tzp/multijoin1` WHERE _c0 is not null and length(_c0)> 1;
382324537
select count(*) from csv.`/user/hive/warehouse/fin_dm_data_ai.db/dm_eco_hdfs_common/tzp/multijoin2` WHERE _c0 is not null and length(_c0)> 1;
324165172

select
t1._c0
from (
    select 
    _c0, count(*) over (partition by _c0) ct 
    from csv.`/user/hive/warehouse/fin_dm_data_ai.db/dm_eco_hdfs_common/tzp/multijoin1`
) t1 left join (
    select 
    _c0, count(*) over (partition by _c0) ct 
    from csv.`/user/hive/warehouse/fin_dm_data_ai.db/dm_eco_hdfs_common/tzp/multijoin2`
) t2 on t1._c0 = t2._c0 and t1.ct = t2.ct
WHERE t2._c0 is null
limit 100
000110247ab17040b429e6f536ff7aaa
000110247ab17040b429e6f536ff7aaa
000110247ab17040b429e6f536ff7aaa
0001c2b74ab7e958bc236b96f4b54646
0001c2b74ab7e958bc236b96f4b54646
0001cc086f62eae87f2b2000eb7bb5ce
0001cc086f62eae87f2b2000eb7bb5ce
0001cc086f62eae87f2b2000eb7bb5ce
000209a4f84f76fce50a6201d2c8eae3
000209a4f84f76fce50a6201d2c8eae3
0002497fe811a40ffbc39fd90dff5754
0002497fe811a40ffbc39fd90dff5754
0002497fe811a40ffbc39fd90dff5754
0002562617e96181397cacedd4a7431c
0002562617e96181397cacedd4a7431c
0002562617e96181397cacedd4a7431c
00028668be75997f0307ca43994f334b
00028668be75997f0307ca43994f334b
00028668be75997f0307ca43994f334b
0002a96ab351b329982564e2fa86028a
0002a96ab351b329982564e2fa86028a
0003a67abe1250d51f60003a8373294d
0003a67abe1250d51f60003a8373294d
0003a67abe1250d51f60003a8373294d
000553b47e7fd6b0eb43cb143298af31
000553b47e7fd6b0eb43cb143298af31
000553b47e7fd6b0eb43cb143298af31
000579b0c22e7da1f665e8b7a95248eb
000579b0c22e7da1f665e8b7a95248eb
0005824915a3a22c75f485996ce06808
0005824915a3a22c75f485996ce06808
0005824915a3a22c75f485996ce06808
0005d01cc3707422463483cb9eda8c8c
0005d01cc3707422463483cb9eda8c8c
0005d01cc3707422463483cb9eda8c8c
0005e0b5750a4df6cc49ebaca4a4601b
0005e0b5750a4df6cc49ebaca4a4601b
000613c89bd2ebddf1405dc9fcebfc1a
000613c89bd2ebddf1405dc9fcebfc1a
000613c89bd2ebddf1405dc9fcebfc1a
000686fcac0e699a1c413ec5356e65e8
000686fcac0e699a1c413ec5356e65e8
000686fcac0e699a1c413ec5356e65e8
0006a967e74db0ba08a4cd3eb2013d3d
0006a967e74db0ba08a4cd3eb2013d3d
0007235c4bf2360985ddfea18844c385
0007235c4bf2360985ddfea18844c385
000776a8a66af129dd1d04362b95ed83
000776a8a66af129dd1d04362b95ed83
00078acec78365443fd19cc3ff4898cc
00078acec78365443fd19cc3ff4898cc
0007f52e67a43bdc22ab4e5fc853bf93
0007f52e67a43bdc22ab4e5fc853bf93
0008769d9496cee9ecf90cb330634b07
0008769d9496cee9ecf90cb330634b07
0008769d9496cee9ecf90cb330634b07
0008c0029ca1c87cecd69e39c8bbec3d
0008c0029ca1c87cecd69e39c8bbec3d
0008c0029ca1c87cecd69e39c8bbec3d
0008efdf720ce5f020bbdc62b3563309
0008efdf720ce5f020bbdc62b3563309
000995127c20375ebbaddaaf03dcaec5
000995127c20375ebbaddaaf03dcaec5
000a483ac730f05253ed359de2056814
000a483ac730f05253ed359de2056814
000ac8c1a349223543ce1bfda96d4aab
000ac8c1a349223543ce1bfda96d4aab
000b0bd509d2dc057aedee64a4b32d9e
000b0bd509d2dc057aedee64a4b32d9e
000b4f6587658d9434348294ad921a22
000b4f6587658d9434348294ad921a22
000d028098f9aa6caaf2cc19cebb1ecb
000d028098f9aa6caaf2cc19cebb1ecb
000d1d6f102afb12f7bd24cc85535a6f
000d1d6f102afb12f7bd24cc85535a6f
000d5d90374eba02f7df48ad24484346
000d5d90374eba02f7df48ad24484346
000d5d90374eba02f7df48ad24484346
000d8ba2fe4cf7bc4b55f8fbae1b80f9
000d8ba2fe4cf7bc4b55f8fbae1b80f9
000ee623a4373ef3cf68dc3672048473
000ee623a4373ef3cf68dc3672048473
000ee623a4373ef3cf68dc3672048473
000ff885630e1528703f081cf4638543
000ff885630e1528703f081cf4638543
00109e95f02af764cff5e5fb18a3fe5d
00109e95f02af764cff5e5fb18a3fe5d
00109e95f02af764cff5e5fb18a3fe5d
00112d55af63b5e89864ea79d1a1d112
00112d55af63b5e89864ea79d1a1d112
00112d55af63b5e89864ea79d1a1d112
0011b6aefe96f402d852b316e45f5892
0011b6aefe96f402d852b316e45f5892
0011b6aefe96f402d852b316e45f5892
0011c087fdffc74819bb5284eaf7b041
0011c087fdffc74819bb5284eaf7b041
0011e7ce97df359b11717e2ff126de30
0011e7ce97df359b11717e2ff126de30
0011e7ce97df359b11717e2ff126de30
0012fc8e419b6257c4f4912280f81c64

SELECT  device_id
        ,imp_count AS t1_imp_count
        ,pday
FROM `fin_dm_data_ai`.`dm_eco_device_feature_impclk_mid_pdi`
WHERE prange = '1w'
AND pday in('20230601','20230602','20230603','20230604')  and device_id = '000110247ab17040b429e6f536ff7aaa'
000110247ab17040b429e6f536ff7aaa        12      20230602
000110247ab17040b429e6f536ff7aaa	12	20230603
000110247ab17040b429e6f536ff7aaa	12	20230604

select * from csv.`/user/hive/warehouse/fin_dm_data_ai.db/dm_eco_hdfs_common/tzp/multijoin1` where _c0 = '000110247ab17040b429e6f536ff7aaa';
000110247ab17040b429e6f536ff7aaa        NULL    12      NULL    NULL
000110247ab17040b429e6f536ff7aaa	NULL	NULL	12	NULL
000110247ab17040b429e6f536ff7aaa	NULL	NULL	NULL	12


select count(*) from csv.`/user/hive/warehouse/fin_dm_data_ai.db/dm_eco_hdfs_common/tzp/multijoin3`;
324165172

java.lang.IllegalStateException: Couldn't find a#8 in []
at org.apache.spark.sql.catalyst.expressions.BindReferences$$anonfun$bindReference$1.applyOrElse(BoundAttribute.scala:80)

# 研究优化器
ColumnPruning如何对自定义LogicalPlan错误优化, 原理解析

1. 优化前

    ```
    Aggregate [count(1) AS count#49L]
    +- MyFullJoin [
        Project [_1#3 AS a#8, _2#4 AS b#9]
            SerializeFromObject
        Project 
        Project 
    ```

    > 原始的join, 在这里稍有区别, 不影响
    ```
    val r = spark.sql("select * from req full outer join imp on req.a = imp.a and req.c > imp.c")
    r.count()
    Aggregate [count(1) AS count#47L]
    +- Project [a#11, b#12, c#13, a#28, b#29, c#30]
        +- Join FullOuter, ((a#11 = a#28) AND (c#13 > c#30))
            :- SubqueryAlias req
            :  +- View (`req`, [a#11,b#12,c#13])
            :     +- Project [_1#4 AS a#11, _2#5 AS b#12, _3#6 AS c#13]
            :        +- SerializeFromObject
            :- SubqueryAlias imp
                ...
    //经过一个什么优化规则后变成了这样, 和MyFullJoin基本一样了
    Aggregate [count(1) AS count#47L]
    +- Join FullOuter, ((a#11 = a#28) AND (c#13 > c#30))
    :- Project [_1#4 AS a#11, _2#5 AS b#12, _3#6 AS c#13]
    :  +- SerializeFromObject [knownnotnull(assertnotnull(input[0, scala.Tuple3, true]))._1 AS _1#4, staticinvoke(class org.apache.spark.unsafe.types.UTF8String, StringType, fromString, knownnotnull(assertnotnull(input[0, scala.Tuple3, true]))._2, true, false) AS _2#5, knownnotnull(assertnotnull(input[0, scala.Tuple3, true]))._3 AS _3#6]
    :     +- ExternalRDD [obj#3]
    +- Project [_1#21 AS a#28, _2#22 AS b#29, _3#23 AS c#30]
        +- SerializeFromObject [knownnotnull(assertnotnull(input[0, scala.Tuple3, true]))._1 AS _1#21, staticinvoke(class org.apache.spark.unsafe.types.UTF8String, StringType, fromString, knownnotnull(assertnotnull(input[0, scala.Tuple3, true]))._2, true, false) AS _2#22, knownnotnull(assertnotnull(input[0, scala.Tuple3, true]))._3 AS _3#23]
            +- ExternalRDD [obj#20]
    ```

2. 进入ColumnPruning优化规则的Aggregate条件
    ```
    case a @ Aggregate(_, _, child) if !child.outputSet.subsetOf(a.references) =>
      a.copy(child = prunedChild(child, a.references))
    ```
    a就是Aggregate逻辑计划, a.references是空集, 所以重新构造了a, 在Aggregate和MyFullJoin中间增加了一层Project(projectList为空的)
    (这么搞不一定有错, 毕竟上面Aggregate啥字段也不需要, project成空的没毛病 ***TODO 普通join这里是否也project成空的了呢?***)

    > 原始的join, 在这里也是一样

3. 先序迭代下一次就是这个新Project进来了, project的case语句很多, 但是进入最后一个
    ```
    case p @ Project(_, child) if !child.isInstanceOf[Project] =>
      val required = child.references ++ p.references
      if (!child.inputSet.subsetOf(required)) {
        val newChildren = child.children.map(c => prunedChild(c, required))
        p.copy(child = child.withNewChildren(newChildren))
      } else {
        p
      }
    ```
    ***由于两个references都是空的***, 所以把child的children也prunedChild(就是我join的三个下级), 走过这条, MyFullJoin变成了
    ```
    MyFullJoin 
        Project [空的]
            Project [_1#3 AS a#8, _2#4 AS b#9]
                SerializeFromObject
        Project
        Project
    ```

    > 原始的join, 在这里, child(Join)的references不是空的, 有4个字段!!

4. 接着MyFullJoin不会进任何优化规则, 走到MyFullJoin的三个child分别进来. 是两个Project挨着
    ```
        case p @ Project(_, p2: Project) if !p2.outputSet.subsetOf(p.references) =>
        p.copy(child = p2.copy(projectList = p2.projectList.filter(p.references.contains)))
    ```
    直接变成两个空的Project相连了.
5. 经过CollapseProject规则, 两个project遍一个, 行程最终看到的样子了


## bug解决
```
//QueryPlan的references是根据expressions生成的, 而expressions如下:
// 这个代码写的不丑:)
  final def expressions: Seq[Expression] = {
    // Recursively find all expressions from a traversable.
    def seqToExpressions(seq: Iterable[Any]): Iterable[Expression] = seq.flatMap {
      case e: Expression => e :: Nil
      case s: Iterable[_] => seqToExpressions(s)
      case other => Nil
    }

    productIterator.flatMap {
      case e: Expression => e :: Nil
      case s: Some[_] => seqToExpressions(s.toSeq)
      case seq: Iterable[_] => seqToExpressions(seq)
      case other => Nil
    }.toSeq
  }
```
由于我定义的MyFullJoin(inputs: List[(LogicalPlan, Expression)])
而Tuple2不能进入他模式匹配的条件里.... 不是Iterable类型的
### 重写一个references方法

## 思考过程
- 优化阶段project没字段了
- SMJExec没啥特殊的
- 可疑的优化规则
  - RemoveNoopOperators
  - ColumnPruning
  - CollapseProject

## 参考代码
```
  所谓pruned, 就是给自己加一层新的Project, 然后先序遍历在优化这个Project
  private def prunedChild(c: LogicalPlan, allReferences: AttributeSet) =
    if (!c.outputSet.subsetOf(allReferences)) {
      Project(c.output.filter(allReferences.contains), c)
    } else {
      c
    }
```
```
  /**
   * 是一波先序遍历
   * Returns a copy of this node where `rule` has been recursively applied to it and all of its
   * children (pre-order). When `rule` does not apply to a given node it is left unchanged.
   */
  def transformDownWithPruning
```

### 关键断点
org.apache.spark.sql.execution.QueryExecution#optimizedPlan
org.apache.spark.sql.catalyst.rules.RuleExecutor#execute: batches.foreach { batch =>
org.apache.spark.sql.catalyst.optimizer.ColumnPruning#prunedChild

在这个规则批batch出现的问题:
Batch(Operator Optimization before Inferring Filters,FixedPoint


# 计划对比
## origin
### count转化前
SMJExec, 下面两个SortExec
### count转化后
AggExec
    AggExec
        ProjectExec (projectList=0)
            SMJExec 下面两个SortExec, output有4列

## custom
### count转化前
sparkPlan: MyFJExec, 下面3个ProjectExec (没加sort/exchange)

executePlan: AdaptiveSparkPlan
    MyFJExec下面3个
    +- Sort [a#32 ASC NULLS FIRST], false, 0
        +- Exchange hashpartitioning(a#32, 1), ENSURE_REQUIREMENTS, [id=#42]
            +- Project [_1#27 AS a#32, _2#28 AS b#33]
                +- SerializeFromObject

### count转化后
AggExec
    AggExec
        MyFJExec
            下面3个SortExec
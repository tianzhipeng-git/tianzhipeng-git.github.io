
with req as (
    select
        coalesce(req1m.device_id,regapply.device_id) as device_id,
        coalesce(req1m.id_type,regapply.id_type) as id_type,
        os,
        is_register,
        register_date,
        is_apply,
        min_appl_date,
        max_appl_date,
        is_ps,
        min_ps_date,
        max_ps_date,
        request_count_1d,
        put_count_1d,
        tt_request_count_1d,
        tt_put_count_1d,
        tencent_request_count_1d,
        tencent_put_count_1d,
        ks_request_count_1d,
        ks_put_count_1d,
        ------ 华丽的分割线
        request_count_3d,
        put_count_3d,
        tt_request_count_3d,
        tt_put_count_3d,
        tencent_request_count_3d,
        tencent_put_count_3d,
        ks_request_count_3d,
        ks_put_count_3d,
        ------ 华丽的分割线
        request_count_1w,
        put_count_1w,
        tt_request_count_1w,
        tt_put_count_1w,
        tencent_request_count_1w,
        tencent_put_count_1w,
        ks_request_count_1w,
        ks_put_count_1w,
        ------ 华丽的分割线
        request_count_2w,
        put_count_2w,
        tt_request_count_2w,
        tt_put_count_2w,
        tencent_request_count_2w,
        tencent_put_count_2w,
        ks_request_count_2w,
        ks_put_count_2w,
        ------ 华丽的分割线
        request_count_1m,
        put_count_1m,
        tt_request_count_1m,
        tt_put_count_1m,
        tencent_request_count_1m,
        tencent_put_count_1m,
        ks_request_count_1m,
        ks_put_count_1m,
        -- 百度 20221212
        baidu_request_count_1d,
        baidu_request_count_3d,
        baidu_request_count_1w,
        baidu_request_count_2w,
        baidu_request_count_1m,
        baidu_put_count_1d,
        baidu_put_count_3d,
        baidu_put_count_1w,
        baidu_put_count_2w,
        baidu_put_count_1m

    from
        (
            select
                device_id,
                id_type,
                os,
                request_count as request_count_1m,
                put_count as put_count_1m,
                tt_request_count as tt_request_count_1m,
                tt_put_count as tt_put_count_1m,
                tencent_request_count as tencent_request_count_1m,
                tencent_put_count as tencent_put_count_1m,
                ks_request_count as ks_request_count_1m,
                ks_put_count as ks_put_count_1m,
                --baidu
                baidu_request_count as baidu_request_count_1m,
                baidu_put_count as baidu_put_count_1m
            from
                `fin_dm_data_ai`.`dm_eco_device_feature_request_mid_pdi`
            where
                    prange = "1m"
              and pday = '${pday}' and length(device_id)=32
        ) req1m
            left join
        (
            select
                device_id,
                id_type,
                request_count as request_count_2w,
                put_count as put_count_2w,
                tt_request_count as tt_request_count_2w,
                tt_put_count as tt_put_count_2w,
                tencent_request_count as tencent_request_count_2w,
                tencent_put_count as tencent_put_count_2w,
                ks_request_count as ks_request_count_2w,
                ks_put_count as ks_put_count_2w,
                --baidu
                baidu_request_count as baidu_request_count_2w,
                baidu_put_count as baidu_put_count_2w
            from
                `fin_dm_data_ai`.`dm_eco_device_feature_request_mid_pdi`
            where
                    prange = "2w"
              and pday = '${pday}'
        ) req2w on req1m.device_id = req2w.device_id and req1m.id_type = req2w.id_type
            left join
        (
            select
                device_id,
                id_type,
                request_count as request_count_1w,
                put_count as put_count_1w,
                tt_request_count as tt_request_count_1w,
                tt_put_count as tt_put_count_1w,
                tencent_request_count as tencent_request_count_1w,
                tencent_put_count as tencent_put_count_1w,
                ks_request_count as ks_request_count_1w,
                ks_put_count as ks_put_count_1w,
                --baidu
                baidu_request_count as baidu_request_count_1w,
                baidu_put_count as baidu_put_count_1w
            from
                `fin_dm_data_ai`.`dm_eco_device_feature_request_mid_pdi`
            where
                    prange = "1w"
              and pday = '${pday}'
        ) req1w on req1m.device_id = req1w.device_id and req1m.id_type = req1w.id_type
            left join
        (
            select
                device_id,
                id_type,
                request_count as request_count_3d,
                put_count as put_count_3d,
                tt_request_count as tt_request_count_3d,
                tt_put_count as tt_put_count_3d,
                tencent_request_count as tencent_request_count_3d,
                tencent_put_count as tencent_put_count_3d,
                ks_request_count as ks_request_count_3d,
                ks_put_count as ks_put_count_3d,
                --baidu
                baidu_request_count as baidu_request_count_3d,
                baidu_put_count as baidu_put_count_3d
            from
                `fin_dm_data_ai`.`dm_eco_device_feature_request_mid_pdi`
            where
                    prange = "3d"
              and pday = '${pday}'
        ) req3d  on req1m.device_id = req3d.device_id and req1m.id_type = req3d.id_type
            left join
        (
            select
                device_id,
                id_type,
                request_count as request_count_1d,
                put_count as put_count_1d,
                tt_request_count as tt_request_count_1d,
                tt_put_count as tt_put_count_1d,
                tencent_request_count as tencent_request_count_1d,
                tencent_put_count as tencent_put_count_1d,
                ks_request_count as ks_request_count_1d,
                ks_put_count as ks_put_count_1d,
                --baidu
                baidu_request_count as baidu_request_count_1d,
                baidu_put_count as baidu_put_count_1d
            from
                `fin_dm_data_ai`.`dm_eco_device_feature_request_mid_pdi`
            where
                    prange = "1d"
              and pday = '${pday}'
        ) req1d on req1m.device_id = req1d.device_id and req1m.id_type = req1d.id_type
            left join
        (
            select
                device_id,
                id_type,
                is_register,
                register_date,
                is_apply,
                min_appl_date,
                max_appl_date,
                is_ps,
                min_ps_date,
                max_ps_date
            from
                `fin_dm_data_ai`.`dm_eco_device_reg_apply_pda`
            where
                    pday = '${pday}'
        ) regapply on req1m.device_id = regapply.device_id and req1m.id_type = regapply.id_type
)

insert overwrite table `fin_dm_data_ai`.`dm_eco_device_feature_profile_pdi` partition (pday = '${pday}')
select
    coalesce(req.device_id,imp.device_id) as device_id,
    coalesce(req.id_type,imp.id_type) as id_type,
    if(coalesce(req.id_type,imp.id_type)='IDFA_MD5','IOS','ANDROID') as os,
    coalesce(req.is_register,imp.is_register) as is_register,
    coalesce(req.register_date,imp.register_date) as register_date,
    coalesce(req.is_apply,imp.is_apply) as is_apply,
    coalesce(req.min_appl_date,imp.min_appl_date) as min_appl_date,
    coalesce(req.max_appl_date,imp.max_appl_date) as max_appl_date,
    coalesce(req.is_ps,imp.is_ps) as is_ps,
    coalesce(req.min_ps_date,imp.min_ps_date) as min_ps_date,
    coalesce(req.max_ps_date,imp.max_ps_date) as max_ps_date,
    coalesce(request_count_1d,0),
    coalesce(put_count_1d,0),
    coalesce(tt_request_count_1d,0),
    coalesce(tt_put_count_1d,0),
    coalesce(tencent_request_count_1d,0),
    coalesce(tencent_put_count_1d,0),
    coalesce(ks_request_count_1d,0),
    coalesce(ks_put_count_1d,0),
    coalesce(imp_count_1d,0),
    coalesce(clk_count_1d,0),
    coalesce(tt_imp_count_1d,0),
    coalesce(tt_clk_count_1d,0),
    coalesce(tt_rta_imp_count_1d,0),
    coalesce(tt_rta_clk_count_1d,0),
    coalesce(tencent_imp_count_1d,0),
    coalesce(tencent_clk_count_1d,0),
    coalesce(tencent_rta_imp_count_1d,0),
    coalesce(tencent_rta_clk_count_1d,0),
    coalesce(ks_imp_count_1d,0),
    coalesce(ks_clk_count_1d,0),
    coalesce(ks_rta_imp_count_1d,0),
    coalesce(ks_rta_clk_count_1d,0),
    coalesce(request_count_3d,0),
    coalesce(put_count_3d,0),
    coalesce(tt_request_count_3d,0),
    coalesce(tt_put_count_3d,0),
    coalesce(tencent_request_count_3d,0),
    coalesce(tencent_put_count_3d,0),
    coalesce(ks_request_count_3d,0),
    coalesce(ks_put_count_3d,0),
    coalesce(imp_count_3d,0),
    coalesce(clk_count_3d,0),
    coalesce(tt_imp_count_3d,0),
    coalesce(tt_clk_count_3d,0),
    coalesce(tt_rta_imp_count_3d,0),
    coalesce(tt_rta_clk_count_3d,0),
    coalesce(tencent_imp_count_3d,0),
    coalesce(tencent_clk_count_3d,0),
    coalesce(tencent_rta_imp_count_3d,0),
    coalesce(tencent_rta_clk_count_3d,0),
    coalesce(ks_imp_count_3d,0),
    coalesce(ks_clk_count_3d,0),
    coalesce(ks_rta_imp_count_3d,0),
    coalesce(ks_rta_clk_count_3d,0),
    coalesce(request_count_1w,0),
    coalesce(put_count_1w,0),
    coalesce(tt_request_count_1w,0),
    coalesce(tt_put_count_1w,0),
    coalesce(tencent_request_count_1w,0),
    coalesce(tencent_put_count_1w,0),
    coalesce(ks_request_count_1w,0),
    coalesce(ks_put_count_1w,0),
    coalesce(imp_count_1w,0),
    coalesce(clk_count_1w,0),
    coalesce(tt_imp_count_1w,0),
    coalesce(tt_clk_count_1w,0),
    coalesce(tt_rta_imp_count_1w,0),
    coalesce(tt_rta_clk_count_1w,0),
    coalesce(tencent_imp_count_1w,0),
    coalesce(tencent_clk_count_1w,0),
    coalesce(tencent_rta_imp_count_1w,0),
    coalesce(tencent_rta_clk_count_1w,0),
    coalesce(ks_imp_count_1w,0),
    coalesce(ks_clk_count_1w,0),
    coalesce(ks_rta_imp_count_1w,0),
    coalesce(ks_rta_clk_count_1w,0),
    coalesce(request_count_2w,0),
    coalesce(put_count_2w,0),
    coalesce(tt_request_count_2w,0),
    coalesce(tt_put_count_2w,0),
    coalesce(tencent_request_count_2w,0),
    coalesce(tencent_put_count_2w,0),
    coalesce(ks_request_count_2w,0),
    coalesce(ks_put_count_2w,0),
    coalesce(imp_count_2w,0),
    coalesce(clk_count_2w,0),
    coalesce(tt_imp_count_2w,0),
    coalesce(tt_clk_count_2w,0),
    coalesce(tt_rta_imp_count_2w,0),
    coalesce(tt_rta_clk_count_2w,0),
    coalesce(tencent_imp_count_2w,0),
    coalesce(tencent_clk_count_2w,0),
    coalesce(tencent_rta_imp_count_2w,0),
    coalesce(tencent_rta_clk_count_2w,0),
    coalesce(ks_imp_count_2w,0),
    coalesce(ks_clk_count_2w,0),
    coalesce(ks_rta_imp_count_2w,0),
    coalesce(ks_rta_clk_count_2w,0),
    coalesce(request_count_1m,0),
    coalesce(put_count_1m,0),
    coalesce(tt_request_count_1m,0),
    coalesce(tt_put_count_1m,0),
    coalesce(tencent_request_count_1m,0),
    coalesce(tencent_put_count_1m,0),
    coalesce(ks_request_count_1m,0),
    coalesce(ks_put_count_1m,0),
    coalesce(imp_count_1m,0),
    coalesce(clk_count_1m,0),
    coalesce(tt_imp_count_1m,0),
    coalesce(tt_clk_count_1m,0),
    coalesce(tt_rta_imp_count_1m,0),
    coalesce(tt_rta_clk_count_1m,0),
    coalesce(tencent_imp_count_1m,0),
    coalesce(tencent_clk_count_1m,0),
    coalesce(tencent_rta_imp_count_1m,0),
    coalesce(tencent_rta_clk_count_1m,0),
    coalesce(ks_imp_count_1m,0),
    coalesce(ks_clk_count_1m,0),
    coalesce(ks_rta_imp_count_1m,0),
    coalesce(ks_rta_clk_count_1m,0),
    --百度曝光点击
    coalesce(baidu_clk_count_1d, 0),
    coalesce(baidu_clk_count_3d, 0),
    coalesce(baidu_clk_count_1w, 0),
    coalesce(baidu_clk_count_2w, 0),
    coalesce(baidu_clk_count_1m, 0),
    coalesce(baidu_imp_count_1d, 0),     -- '百度最近1天的曝光次数'
    coalesce(baidu_imp_count_3d, 0),     -- '百度最近3天的曝光次数'
    coalesce(baidu_imp_count_1w, 0),     -- '百度最近7天的曝光次数'
    coalesce(baidu_imp_count_2w, 0),     -- '百度最近15天的曝光次数'
    coalesce(baidu_imp_count_1m, 0),     -- '百度最近30天的曝光次数'
    coalesce(baidu_rta_clk_count_1d, 0), -- '百度最近1天的rta点击次数'
    coalesce(baidu_rta_clk_count_3d, 0), -- '百度最近3天的rta点击次数'
    coalesce(baidu_rta_clk_count_1w, 0), -- '百度最近7天的rta点击次数'
    coalesce(baidu_rta_clk_count_2w, 0), -- '百度最近15天的rta点击次数'
    coalesce(baidu_rta_clk_count_1m, 0), -- '百度最近30天的rta点击次数'
    coalesce(baidu_rta_imp_count_1d, 0), -- '百度最近1天的rta曝光次数'
    coalesce(baidu_rta_imp_count_3d, 0), -- '百度最近3天的rta曝光次数'
    coalesce(baidu_rta_imp_count_1w, 0), -- '百度最近7天的rta曝光次数'
    coalesce(baidu_rta_imp_count_2w, 0), -- '百度最近15天的rta曝光次数'
    coalesce(baidu_rta_imp_count_1m, 0), -- '百度最近30天的rta曝光次数'
    --百度请求参竞
    coalesce(baidu_put_count_1d, 0),     -- '百度最近1天的参竞次数'
    coalesce(baidu_put_count_3d, 0),     -- '百度最近3天的参竞次数'
    coalesce(baidu_put_count_1w, 0),     -- '百度最近7天的参竞次数'
    coalesce(baidu_put_count_2w, 0),     -- '百度最近15天的参竞次数'
    coalesce(baidu_put_count_1m, 0),     -- '百度最近30天的参竞次数'
    coalesce(baidu_request_count_1d, 0), -- '百度最近1天的请求次数'
    coalesce(baidu_request_count_3d, 0), -- '百度最近3天的请求次数'
    coalesce(baidu_request_count_1w, 0), -- '百度最近7天的请求次数'
    coalesce(baidu_request_count_2w, 0), -- '百度最近15天的请求次数'
    coalesce(baidu_request_count_1m, 0)  -- '百度最近30天的请求次数'



from
    req
        full outer join
    (

        select
            coalesce(imp1m.device_id,regapply.device_id) as device_id,
            coalesce(imp1m.id_type,regapply.id_type) as id_type,
            os,
            is_register,
            register_date,
            is_apply,
            min_appl_date,
            max_appl_date,
            is_ps,
            min_ps_date,
            max_ps_date,
            imp_count_1d,
            clk_count_1d,
            tt_imp_count_1d,
            tt_clk_count_1d,
            tt_rta_imp_count_1d,
            tt_rta_clk_count_1d,
            tencent_imp_count_1d,
            tencent_clk_count_1d,
            tencent_rta_imp_count_1d,
            tencent_rta_clk_count_1d,
            ks_imp_count_1d,
            ks_clk_count_1d,
            ks_rta_imp_count_1d,
            ks_rta_clk_count_1d,
            -- baidu
            baidu_imp_count_1d,
            baidu_clk_count_1d,
            baidu_rta_imp_count_1d,
            baidu_rta_clk_count_1d,
            -----
            imp_count_3d,
            clk_count_3d,
            tt_imp_count_3d,
            tt_clk_count_3d,
            tt_rta_imp_count_3d,
            tt_rta_clk_count_3d,
            tencent_imp_count_3d,
            tencent_clk_count_3d,
            tencent_rta_imp_count_3d,
            tencent_rta_clk_count_3d,
            ks_imp_count_3d,
            ks_clk_count_3d,
            ks_rta_imp_count_3d,
            ks_rta_clk_count_3d,
            -- baidu
            baidu_imp_count_3d,
            baidu_clk_count_3d,
            baidu_rta_imp_count_3d,
            baidu_rta_clk_count_3d,
            ----
            imp_count_1w,
            clk_count_1w,
            tt_imp_count_1w,
            tt_clk_count_1w,
            tt_rta_imp_count_1w,
            tt_rta_clk_count_1w,
            tencent_imp_count_1w,
            tencent_clk_count_1w,
            tencent_rta_imp_count_1w,
            tencent_rta_clk_count_1w,
            ks_imp_count_1w,
            ks_clk_count_1w,
            ks_rta_imp_count_1w,
            ks_rta_clk_count_1w,
            -- baidu
            baidu_imp_count_1w,
            baidu_clk_count_1w,
            baidu_rta_imp_count_1w,
            baidu_rta_clk_count_1w,
            ----
            imp_count_2w,
            clk_count_2w,
            tt_imp_count_2w,
            tt_clk_count_2w,
            tt_rta_imp_count_2w,
            tt_rta_clk_count_2w,
            tencent_imp_count_2w,
            tencent_clk_count_2w,
            tencent_rta_imp_count_2w,
            tencent_rta_clk_count_2w,
            ks_imp_count_2w,
            ks_clk_count_2w,
            ks_rta_imp_count_2w,
            ks_rta_clk_count_2w,
            -- baidu
            baidu_imp_count_2w,
            baidu_clk_count_2w,
            baidu_rta_imp_count_2w,
            baidu_rta_clk_count_2w,
            ----
            imp_count_1m,
            clk_count_1m,
            tt_imp_count_1m,
            tt_clk_count_1m,
            tt_rta_imp_count_1m,
            tt_rta_clk_count_1m,
            tencent_imp_count_1m,
            tencent_clk_count_1m,
            tencent_rta_imp_count_1m,
            tencent_rta_clk_count_1m,
            ks_imp_count_1m,
            ks_clk_count_1m,
            ks_rta_imp_count_1m,
            ks_rta_clk_count_1m,
            -- baidu
            baidu_imp_count_1m,
            baidu_clk_count_1m,
            baidu_rta_imp_count_1m,
            baidu_rta_clk_count_1m

        from (
                 select
                     device_id,
                     id_type,
                     os,
                     imp_count as imp_count_1m,
                     clk_count as clk_count_1m,
                     tt_imp_count as tt_imp_count_1m,
                     tt_clk_count as tt_clk_count_1m,
                     tt_rta_imp_count as tt_rta_imp_count_1m,
                     tt_rta_clk_count as tt_rta_clk_count_1m,
                     tencent_imp_count as tencent_imp_count_1m,
                     tencent_clk_count as tencent_clk_count_1m,
                     tencent_rta_imp_count as tencent_rta_imp_count_1m,
                     tencent_rta_clk_count as tencent_rta_clk_count_1m,
                     ks_imp_count as ks_imp_count_1m,
                     ks_clk_count as ks_clk_count_1m,
                     ks_rta_imp_count as ks_rta_imp_count_1m,
                     ks_rta_clk_count as ks_rta_clk_count_1m,
                     --baidu
                     baidu_imp_count as baidu_imp_count_1m,
                     baidu_clk_count as baidu_clk_count_1m,
                     baidu_rta_imp_count as baidu_rta_imp_count_1m,
                     baidu_rta_clk_count as baidu_rta_clk_count_1m
                 from
                     `fin_dm_data_ai`.`dm_eco_device_feature_impclk_mid_pdi`
                 where
                         prange = "1m"
                   and pday = '${pday}' and length(device_id)=32
             ) imp1m
                 left join (
            select
                device_id,
                id_type,
                imp_count as imp_count_2w,
                clk_count as clk_count_2w,
                tt_imp_count as tt_imp_count_2w,
                tt_clk_count as tt_clk_count_2w,
                tt_rta_imp_count as tt_rta_imp_count_2w,
                tt_rta_clk_count as tt_rta_clk_count_2w,
                tencent_imp_count as tencent_imp_count_2w,
                tencent_clk_count as tencent_clk_count_2w,
                tencent_rta_imp_count as tencent_rta_imp_count_2w,
                tencent_rta_clk_count as tencent_rta_clk_count_2w,
                ks_imp_count as ks_imp_count_2w,
                ks_clk_count as ks_clk_count_2w,
                ks_rta_imp_count as ks_rta_imp_count_2w,
                ks_rta_clk_count as ks_rta_clk_count_2w,
                --baidu
                baidu_imp_count as baidu_imp_count_2w,
                baidu_clk_count as baidu_clk_count_2w,
                baidu_rta_imp_count as baidu_rta_imp_count_2w,
                baidu_rta_clk_count as baidu_rta_clk_count_2w
            from
                `fin_dm_data_ai`.`dm_eco_device_feature_impclk_mid_pdi`
            where
                    prange = "2w"
              and pday = '${pday}'
        ) imp2w on imp1m.device_id = imp2w.device_id and imp1m.id_type = imp2w.id_type
                 left join (
            select
                device_id,
                id_type,
                imp_count as imp_count_1w,
                clk_count as clk_count_1w,
                tt_imp_count as tt_imp_count_1w,
                tt_clk_count as tt_clk_count_1w,
                tt_rta_imp_count as tt_rta_imp_count_1w,
                tt_rta_clk_count as tt_rta_clk_count_1w,
                tencent_imp_count as tencent_imp_count_1w,
                tencent_clk_count as tencent_clk_count_1w,
                tencent_rta_imp_count as tencent_rta_imp_count_1w,
                tencent_rta_clk_count as tencent_rta_clk_count_1w,
                ks_imp_count as ks_imp_count_1w,
                ks_clk_count as ks_clk_count_1w,
                ks_rta_imp_count as ks_rta_imp_count_1w,
                ks_rta_clk_count as ks_rta_clk_count_1w,
                --baidu
                baidu_imp_count as baidu_imp_count_1w,
                baidu_clk_count as baidu_clk_count_1w,
                baidu_rta_imp_count as baidu_rta_imp_count_1w,
                baidu_rta_clk_count as baidu_rta_clk_count_1w
            from
                `fin_dm_data_ai`.`dm_eco_device_feature_impclk_mid_pdi`
            where
                    prange = "1w"
              and pday = '${pday}'
        ) imp1w on imp1m.device_id = imp1w.device_id and imp1m.id_type = imp1w.id_type
                 left join (
            select
                device_id,
                id_type,
                imp_count as imp_count_3d,
                clk_count as clk_count_3d,
                tt_imp_count as tt_imp_count_3d,
                tt_clk_count as tt_clk_count_3d,
                tt_rta_imp_count as tt_rta_imp_count_3d,
                tt_rta_clk_count as tt_rta_clk_count_3d,
                tencent_imp_count as tencent_imp_count_3d,
                tencent_clk_count as tencent_clk_count_3d,
                tencent_rta_imp_count as tencent_rta_imp_count_3d,
                tencent_rta_clk_count as tencent_rta_clk_count_3d,
                ks_imp_count as ks_imp_count_3d,
                ks_clk_count as ks_clk_count_3d,
                ks_rta_imp_count as ks_rta_imp_count_3d,
                ks_rta_clk_count as ks_rta_clk_count_3d,
                --baidu
                baidu_imp_count as baidu_imp_count_3d,
                baidu_clk_count as baidu_clk_count_3d,
                baidu_rta_imp_count as baidu_rta_imp_count_3d,
                baidu_rta_clk_count as baidu_rta_clk_count_3d
            from
                `fin_dm_data_ai`.`dm_eco_device_feature_impclk_mid_pdi`
            where
                    prange = "3d"
              and pday = '${pday}'
        ) imp3d on imp1m.device_id = imp3d.device_id and imp1m.id_type = imp3d.id_type
                 left join (
            select
                device_id,
                id_type,
                imp_count as imp_count_1d,
                clk_count as clk_count_1d,
                tt_imp_count as tt_imp_count_1d,
                tt_clk_count as tt_clk_count_1d,
                tt_rta_imp_count as tt_rta_imp_count_1d,
                tt_rta_clk_count as tt_rta_clk_count_1d,
                tencent_imp_count as tencent_imp_count_1d,
                tencent_clk_count as tencent_clk_count_1d,
                tencent_rta_imp_count as tencent_rta_imp_count_1d,
                tencent_rta_clk_count as tencent_rta_clk_count_1d,
                ks_imp_count as ks_imp_count_1d,
                ks_clk_count as ks_clk_count_1d,
                ks_rta_imp_count as ks_rta_imp_count_1d,
                ks_rta_clk_count as ks_rta_clk_count_1d,
                --baidu
                baidu_imp_count as baidu_imp_count_1d,
                baidu_clk_count as baidu_clk_count_1d,
                baidu_rta_imp_count as baidu_rta_imp_count_1d,
                baidu_rta_clk_count as baidu_rta_clk_count_1d
            from
                `fin_dm_data_ai`.`dm_eco_device_feature_impclk_mid_pdi`
            where
                    prange = "1d"
              and pday = '${pday}'
        ) imp1d on imp1m.device_id = imp1d.device_id and imp1m.id_type = imp1d.id_type
                 left join
             (
                 select
                     device_id,
                     id_type,
                     is_register,
                     register_date,
                     is_apply,
                     min_appl_date,
                     max_appl_date,
                     is_ps,
                     min_ps_date,
                     max_ps_date
                 from
                     `fin_dm_data_ai`.`dm_eco_device_reg_apply_pda`
                 where
                         pday = '${pday}'
             ) regapply on imp1m.device_id = regapply.device_id and imp1m.id_type = regapply.id_type
    ) imp on req.device_id = imp.device_id and req.id_type = imp.id_type
    DISTRIBUTE BY rand();

